
import studentMain

if callable(getattr(studentMain, 'performMagicIncantation', None)):
    studentMain.performMagicIncantation() 
